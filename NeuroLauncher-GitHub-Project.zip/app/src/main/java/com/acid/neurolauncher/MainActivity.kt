package com.acid.neurolauncher

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.app.Activity
import org.json.JSONArray

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private val selected = mutableListOf<String>()
    private lateinit var grid: GridLayout
    private lateinit var countText: TextView
    private val bg = Color.rgb(5, 8, 18)
    private val cyan = Color.rgb(94, 220, 255)
    private val white = Color.rgb(245, 248, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        loadSelected()
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(5, 9, 22), Color.rgb(8, 22, 42), Color.rgb(3, 5, 12)))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "NEURO"
            textSize = 14f
            letterSpacing = .24f
            setTextColor(cyan)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val status = TextView(this).apply {
            text = "PERSONAL SPACE  •  01"
            textSize = 10f
            letterSpacing = .08f
            setTextColor(Color.rgb(132, 160, 190))
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }
        top.addView(brand, LinearLayout.LayoutParams(0, dp(28), 1f))
        top.addView(status)
        content.addView(top)

        val hero = TextView(this).apply {
            text = "Твои приложения.\nТвой ритм."
            textSize = 34f
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setLineSpacing(dp(1).toFloat(), 1f)
            setPadding(0, dp(28), 0, dp(8))
        }
        content.addView(hero)

        val subtitle = TextView(this).apply {
            text = "Быстрый доступ ко всему важному"
            textSize = 14f
            setTextColor(Color.rgb(153, 174, 198))
        }
        content.addView(subtitle)

        val search = EditText(this).apply {
            hint = "  Поиск по ярлыкам"
            setHintTextColor(Color.rgb(120, 145, 171))
            setTextColor(white)
            textSize = 14f
            singleLine = true
            background = panelDrawable(22, Color.rgb(13, 25, 43), Color.rgb(37, 68, 96))
            setPadding(dp(16), 0, dp(16), 0)
        }
        val searchParams = LinearLayout.LayoutParams(-1, dp(50))
        searchParams.topMargin = dp(22)
        content.addView(search, searchParams)

        val section = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(24), 0, dp(12))
        }
        val heading = TextView(this).apply {
            text = "БЫСТРЫЙ ЗАПУСК"
            textSize = 12f
            letterSpacing = .13f
            setTextColor(Color.rgb(187, 207, 229))
            typeface = Typeface.DEFAULT_BOLD
        }
        countText = TextView(this).apply {
            textSize = 11f
            setTextColor(cyan)
            gravity = Gravity.RIGHT
        }
        section.addView(heading, LinearLayout.LayoutParams(0, dp(24), 1f))
        section.addView(countText)
        content.addView(section)

        grid = GridLayout(this).apply { columnCount = 4; useDefaultMargins = false }
        content.addView(grid, LinearLayout.LayoutParams(-1, -2))

        val tip = TextView(this).apply {
            text = "Подсказка: удерживай иконку, чтобы убрать её из сетки."
            textSize = 12f
            setTextColor(Color.rgb(113, 140, 166))
            setPadding(2, dp(18), 2, dp(12))
        }
        content.addView(tip)
        setContentView(root)

        search.addTextChangedListener(SimpleTextWatcher { query ->
            renderGrid(query.trim().lowercase())
        })
        renderGrid()
    }

    private fun renderGrid(query: String = "") {
        grid.removeAllViews()
        val pm = packageManager
        val entries = selected.mapNotNull { pkg ->
            try {
                val app = pm.getApplicationInfo(pkg, 0)
                Triple(pkg, pm.getApplicationLabel(app).toString(), pm.getApplicationIcon(app))
            } catch (_: Exception) { null }
        }.filter { it.second.lowercase().contains(query) }

        entries.forEach { (pkg, label, icon) ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(8), dp(3), dp(12))
                isClickable = true
                isFocusable = true
                background = rippleDrawable()
            }
            val image = ImageView(this).apply {
                setImageDrawable(icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(13), dp(13), dp(13), dp(13))
                background = panelDrawable(20, Color.rgb(18, 34, 55), Color.rgb(37, 77, 105))
            }
            cell.addView(image, LinearLayout.LayoutParams(dp(58), dp(58)))
            val title = TextView(this).apply {
                text = label
                textSize = 10.5f
                setTextColor(white)
                gravity = Gravity.CENTER
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(0, dp(7), 0, 0)
            }
            cell.addView(title, LinearLayout.LayoutParams(-1, dp(34)))
            cell.setOnClickListener { launchApp(pkg) }
            cell.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle(label)
                    .setMessage("Убрать ярлык из быстрого запуска?")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Убрать") { _, _ ->
                        selected.remove(pkg); saveSelected(); renderGrid(query)
                    }.show()
                true
            }
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(112)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(2), dp(2), dp(2), dp(2))
            }
            grid.addView(cell, lp)
        }

        val addCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(8), dp(3), dp(12))
            isClickable = true
            background = rippleDrawable()
            setOnClickListener { showAppPicker() }
        }
        val plus = TextView(this).apply {
            text = "+"
            textSize = 36f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            background = panelDrawable(20, Color.rgb(10, 30, 48), Color.rgb(47, 139, 177))
        }
        addCell.addView(plus, LinearLayout.LayoutParams(dp(58), dp(58)))
        addCell.addView(TextView(this).apply {
            text = "Добавить"
            textSize = 10.5f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, 0)
        }, LinearLayout.LayoutParams(-1, dp(34)))
        val addLp = GridLayout.LayoutParams().apply {
            width = 0; height = dp(112)
            columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }
        grid.addView(addCell, addLp)
        countText.text = "${selected.size} ЯРЛЫКОВ"
    }

    private fun showAppPicker() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { ri ->
                val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == packageName || selected.contains(pkg)) return@mapNotNull null
                Triple(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm))
            }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

        if (apps.isEmpty()) {
            Toast.makeText(this, "Все доступные приложения уже добавлены", Toast.LENGTH_SHORT).show()
            return
        }

        val list = ListView(this)
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(position: Int) = apps[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val (pkg, label, icon) = apps[position]
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(18), dp(9), dp(18), dp(9))
                }
                val iv = ImageView(this@MainActivity).apply { setImageDrawable(icon) }
                row.addView(iv, LinearLayout.LayoutParams(dp(42), dp(42)))
                val text = TextView(this@MainActivity).apply {
                    this.text = "$label\n$pkg"
                    textSize = 13f
                    setTextColor(white)
                    setPadding(dp(14), 0, 0, 0)
                }
                row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
                val add = TextView(this@MainActivity).apply {
                    text = "+"
                    textSize = 25f
                    setTextColor(cyan)
                }
                row.addView(add)
                return row
            }
        }
        list.adapter = adapter
        val dialog = AlertDialog.Builder(this)
            .setTitle("Добавить приложение")
            .setView(list)
            .setNegativeButton("Готово", null)
            .create()
        list.setOnItemClickListener { _, _, position, _ ->
            selected.add(apps[position].first)
            saveSelected()
            renderGrid()
            dialog.dismiss()
            Toast.makeText(this, "${apps[position].second} добавлено", Toast.LENGTH_SHORT).show()
        }
        dialog.show()
    }

    private fun launchApp(pkg: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
        } else {
            Toast.makeText(this, "Не удалось открыть приложение", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadSelected() {
        selected.clear()
        val json = prefs.getString("apps", null) ?: return
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) selected.add(arr.getString(i))
        } catch (_: Exception) { }
    }

    private fun saveSelected() {
        val arr = JSONArray()
        selected.forEach { arr.put(it) }
        prefs.edit().putString("apps", arr.toString()).apply()
    }

    private fun panelDrawable(radius: Int, fill: Int, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(radius).toFloat()
            setColor(fill)
            setStroke(dp(1), stroke)
        }

    private fun rippleDrawable(): android.graphics.drawable.Drawable {
        val content = panelDrawable(18, Color.argb(35, 120, 180, 220), Color.argb(25, 160, 210, 255))
        return android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(Color.argb(45, 94, 220, 255)), content, null)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
